=== Plain Counter ===
Contributors: grintender
Tags: wordpress, plugin, counter
Requires at least: 3.9
Tested up to: 4.5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


All things count. Projects done and coffee consumed.


== Installation ==

To install "Plain Counter" do the following steps:

1. Download the plugin from Envato
2. Upload the ZIP file through the 'Plugins > Add New > Upload' screen in your WordPress dashboard
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Navigate to Settings > Plain Counter Settings and follow your inner voice along with our tips

== Frequently Asked Questions ==

Send an email at editor@the.gt

== Changelog ==

= 1.0 =
* 2016-06-16
* Initial release

== Upgrade Notice ==

= 1.0 =
* 2016-06-16
* Initial release
